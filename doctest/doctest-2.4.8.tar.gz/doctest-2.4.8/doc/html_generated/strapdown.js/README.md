lbesson.bitbucket.org/md/
=========================

[StrapDown.js](https://lbesson.bitbucket.org/md/index.html)
is an awesome tool to write nice-looking webpages in pure Markdown, with no server side compilation (as the page you are reading).

### More details
More details on http://lbesson.bitbucket.org/md/index.html,
with example and all.

----

# About
### Hacked by [Lilian Besson](https://bitbucket.org/lbesson).

### Languages
 - JavaScript;
 - HTML 5 and CSS 3.

### License
This project is released under the **GPLv3 license**, for more details,
take a look at the [LICENSE](http://besson.qc.to/LICENSE.html) file in the source.

*Basically, that allow you to use all or part of the project for you own business.*
