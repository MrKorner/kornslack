#include "doctest_fwd.h"
#ifndef DOCTEST_SINGLE_HEADER
#define DOCTEST_SINGLE_HEADER
#endif
#include "doctest.cpp"
